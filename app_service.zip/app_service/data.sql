create table user_info(
	id int PRIMARY KEY AUTO_INCREMENT,
	username varchar(16),
	password varchar(16)
)CHARACTER SET utf8 ;